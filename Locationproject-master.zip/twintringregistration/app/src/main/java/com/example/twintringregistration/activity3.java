package com.example.twintringregistration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class activity3 extends AppCompatActivity {
    Button rider,ride,routes,challenge ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity3);
        rider=(Button) findViewById(R.id.rider);
        routes=(Button)findViewById(R.id.routes);
        challenge = (Button)findViewById(R.id.challenge);

        ride = (Button)findViewById(R.id.ride);
        challenge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openchallengeactivity();

            }
        });
        ride.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openridesactivity();
            }
        });
        routes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openrouteactivity();
            }
        });
        rider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openrideractivity();
            }
        });


    }
    void openrideractivity()
    {
        Intent intent = new Intent(this,rider.class);
        startActivity(intent);

    }
    void openrouteactivity()
    {
        Intent intent = new Intent(this,routes.class);
        startActivity(intent);

    }
    void openridesactivity()
    {
        Intent intent = new Intent(this,rides.class);
        startActivity(intent);

    }
    void openchallengeactivity()
    {
        Intent intent = new Intent(this,challenge.class);
        startActivity(intent);

    }




}
