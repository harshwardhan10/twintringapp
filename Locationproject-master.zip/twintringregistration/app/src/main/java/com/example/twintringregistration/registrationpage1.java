package com.example.twintringregistration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

public class registrationpage1 extends AppCompatActivity {
    EditText  memail , mpassword , mphone;
    Button mgobtn;
    TextView mloginbtn;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrationpage1);
        memail = findViewById(R.id.email);
        mpassword = findViewById(R.id.password);
        mphone = findViewById(R.id.phone);
        mgobtn = (Button) findViewById(R.id.gobutton);
        mloginbtn = findViewById(R.id.createtext);
        progressBar = findViewById(R.id.progressBar);
        mgobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = memail.getText().toString().trim();
                String password = mpassword.getText().toString().trim();

                if(TextUtils.isEmpty(email)){
                    memail.setError("email is required");
                    return;
                }

                if(mphone.getText().toString().isEmpty() ) {
                    mphone.setError("phone number is required ");
                    return;
                }
                if(mphone.getText().toString().length()<10)
                {
                    mphone.setError("invalid number");
                    return;
                }
                if(TextUtils.isEmpty(password)){
                    mpassword.setError("password is requried");
                    return;
                }

                if(password.length()<6){
                    mpassword.setError("password must be >=6 character");
                    return;

                }

                openregistrationpage2();
                progressBar.setVisibility(View.VISIBLE);

            }

        });

    }
    public  void openregistrationpage2()
    {

        Intent intent = new Intent(this,registrationpage2.class);
        startActivity(intent);
    }
}
